import pandas as pd
import numpy as np
from typing import Tuple, Optional

def validate_data(df: pd.DataFrame) -> Tuple[bool, Optional[str]]:
    """
    Validate the input data format for delivery time prediction
    
    Args:
        df: Input DataFrame to validate
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    required_columns = ['distance', 'weight', 'shipping_method', 'delivery_days']
    
    # Check if all required columns are present
    missing_cols = [col for col in required_columns if col not in df.columns]
    if missing_cols:
        return False, f"Missing required columns: {', '.join(missing_cols)}"
    
    # Check data types and ranges
    try:
        # Distance should be positive numeric
        if not pd.api.types.is_numeric_dtype(df['distance']):
            return False, "Distance column must be numeric"
        if (df['distance'] <= 0).any():
            return False, "Distance must be greater than 0"
        
        # Weight should be positive numeric
        if not pd.api.types.is_numeric_dtype(df['weight']):
            return False, "Weight column must be numeric"
        if (df['weight'] <= 0).any():
            return False, "Weight must be greater than 0"
        
        # Shipping method should be 1 or 2
        if not pd.api.types.is_numeric_dtype(df['shipping_method']):
            return False, "Shipping method column must be numeric"
        valid_methods = df['shipping_method'].isin([1, 2])
        if not valid_methods.all():
            return False, "Shipping method must be 1 (standard) or 2 (priority)"
        
        # Delivery days should be positive numeric
        if not pd.api.types.is_numeric_dtype(df['delivery_days']):
            return False, "Delivery days column must be numeric"
        if (df['delivery_days'] <= 0).any():
            return False, "Delivery days must be greater than 0"
        
        # Check for reasonable ranges
        if (df['distance'] > 10000).any():
            return False, "Distance seems unreasonably large (>10,000 km)"
        if (df['weight'] > 1000).any():
            return False, "Weight seems unreasonably large (>1,000 kg)"
        if (df['delivery_days'] > 100).any():
            return False, "Delivery days seem unreasonably large (>100 days)"
        
        # Check for missing values
        if df[required_columns].isnull().any().any():
            return False, "Data contains missing values"
        
        # Minimum data size
        if len(df) < 10:
            return False, "Need at least 10 records for training"
        
    except Exception as e:
        return False, f"Data validation error: {str(e)}"
    
    return True, None

def create_sample_data_format() -> pd.DataFrame:
    """
    Create a sample DataFrame showing the expected data format
    
    Returns:
        Sample DataFrame with correct column structure
    """
    sample_data = {
        'distance': [150, 300, 750, 50, 1200],
        'weight': [1.5, 3.2, 0.8, 5.0, 2.1],
        'shipping_method': [1, 2, 1, 2, 1],
        'delivery_days': [3, 2, 7, 1, 8]
    }
    
    return pd.DataFrame(sample_data)

def generate_synthetic_data(n_samples: int = 1000, random_seed: int = 42) -> pd.DataFrame:
    """
    Generate synthetic delivery data for testing purposes
    
    Args:
        n_samples: Number of samples to generate
        random_seed: Random seed for reproducibility
    
    Returns:
        DataFrame with synthetic delivery data
    """
    np.random.seed(random_seed)
    
    # Generate features
    distances = np.random.exponential(300, n_samples)  # Exponential distribution for distances
    distances = np.clip(distances, 10, 2000)  # Clip to reasonable range
    
    weights = np.random.lognormal(0.5, 0.8, n_samples)  # Log-normal for weights
    weights = np.clip(weights, 0.1, 50)  # Clip to reasonable range
    
    shipping_methods = np.random.choice([1, 2], n_samples, p=[0.7, 0.3])  # 70% standard, 30% priority
    
    # Generate delivery times based on features with some realistic logic
    base_time = (distances / 200) + (weights * 0.2) + np.random.normal(0, 0.5, n_samples)
    
    # Adjust for shipping method (priority is faster)
    priority_reduction = np.where(shipping_methods == 2, 
                                np.random.uniform(0.5, 2.0, n_samples), 0)
    
    delivery_days = base_time - priority_reduction + np.random.normal(0, 0.3, n_samples)
    delivery_days = np.clip(delivery_days, 0.5, 30)  # Clip to reasonable range
    
    # Create DataFrame
    synthetic_df = pd.DataFrame({
        'distance': distances.round(0),
        'weight': weights.round(1),
        'shipping_method': shipping_methods,
        'delivery_days': delivery_days.round(1)
    })
    
    return synthetic_df

def preprocess_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Preprocess the data for better model performance
    
    Args:
        df: Input DataFrame
    
    Returns:
        Preprocessed DataFrame
    """
    df_processed = df.copy()
    
    # Remove any extreme outliers using IQR method
    for column in ['distance', 'weight', 'delivery_days']:
        Q1 = df_processed[column].quantile(0.25)
        Q3 = df_processed[column].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        
        df_processed = df_processed[
            (df_processed[column] >= lower_bound) & 
            (df_processed[column] <= upper_bound)
        ]
    
    # Reset index after filtering
    df_processed = df_processed.reset_index(drop=True)
    
    return df_processed

def calculate_delivery_stats(df: pd.DataFrame) -> dict:
    """
    Calculate summary statistics for delivery data
    
    Args:
        df: DataFrame with delivery data
    
    Returns:
        Dictionary with summary statistics
    """
    stats = {}
    
    # Overall statistics
    stats['total_records'] = len(df)
    stats['avg_delivery_days'] = df['delivery_days'].mean()
    stats['median_delivery_days'] = df['delivery_days'].median()
    stats['std_delivery_days'] = df['delivery_days'].std()
    
    # Statistics by shipping method
    standard_data = df[df['shipping_method'] == 1]
    priority_data = df[df['shipping_method'] == 2]
    
    stats['standard_avg_days'] = standard_data['delivery_days'].mean() if len(standard_data) > 0 else None
    stats['priority_avg_days'] = priority_data['delivery_days'].mean() if len(priority_data) > 0 else None
    
    # Distance and weight ranges
    stats['distance_range'] = (df['distance'].min(), df['distance'].max())
    stats['weight_range'] = (df['weight'].min(), df['weight'].max())
    
    # Shipping method distribution
    method_counts = df['shipping_method'].value_counts()
    stats['standard_percentage'] = (method_counts.get(1, 0) / len(df)) * 100
    stats['priority_percentage'] = (method_counts.get(2, 0) / len(df)) * 100
    
    return stats

def export_predictions(predictions: list, features: pd.DataFrame, filepath: str):
    """
    Export predictions to a CSV file
    
    Args:
        predictions: List of predicted delivery times
        features: DataFrame with input features
        filepath: Path to save the CSV file
    """
    results_df = features.copy()
    results_df['predicted_delivery_days'] = predictions
    results_df['shipping_method_name'] = results_df['shipping_method'].map({
        1: 'Standard',
        2: 'Priority'
    })
    
    results_df.to_csv(filepath, index=False)
