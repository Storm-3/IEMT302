import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import pickle
import io

from ml_models import DeliveryTimePredictor
from data_utils import validate_data, create_sample_data_format

# Page configuration
st.set_page_config(
    page_title="Package Delivery Time Predictor",
    page_icon="📦",
    layout="wide"
)

# Initialize session state
if 'model' not in st.session_state:
    st.session_state.model = None
if 'training_data' not in st.session_state:
    st.session_state.training_data = None
if 'model_metrics' not in st.session_state:
    st.session_state.model_metrics = None

# Main title
st.title("📦 Package Delivery Time Predictor")
st.markdown("Predict delivery times based on distance, package weight, and shipping method")

# Sidebar for navigation
st.sidebar.title("Navigation")
page = st.sidebar.selectbox("Select Page", 
    ["Data Upload & Training", "Make Predictions", "Model Performance", "Feature Analysis"])

if page == "Data Upload & Training":
    st.header("📊 Data Upload & Model Training")
    
    # Data upload section
    st.subheader("Upload Training Data")
    
    # Show expected data format
    with st.expander("Expected Data Format"):
        st.markdown("""
        Your CSV file should contain the following columns:
        - **distance**: Distance between sender and receiver in kilometers (numeric)
        - **weight**: Package weight in kilograms (numeric)
        - **shipping_method**: 1 for standard, 2 for priority (numeric)
        - **delivery_days**: Number of days for delivery (target variable, numeric)
        
        Example:
        """)
        sample_df = create_sample_data_format()
        st.dataframe(sample_df)
    
    # File upload
    uploaded_file = st.file_uploader("Choose a CSV file", type="csv")
    
    if uploaded_file is not None:
        try:
            # Load and validate data
            df = pd.read_csv(uploaded_file)
            st.success("✅ File uploaded successfully!")
            
            # Display data info
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Total Records", len(df))
            with col2:
                st.metric("Features", len(df.columns))
            
            # Validate data format
            validation_result, error_msg = validate_data(df)
            
            if validation_result:
                st.success("✅ Data format is valid!")
                
                # Display data preview
                st.subheader("Data Preview")
                st.dataframe(df.head(10))
                
                # Data statistics
                st.subheader("Data Statistics")
                st.dataframe(df.describe())
                
                # Data distribution plots
                st.subheader("Data Distribution")
                fig_cols = st.columns(2)
                
                with fig_cols[0]:
                    fig_dist = px.histogram(df, x='delivery_days', 
                                          title='Distribution of Delivery Days',
                                          nbins=20)
                    st.plotly_chart(fig_dist, use_container_width=True)
                
                with fig_cols[1]:
                    fig_method = px.histogram(df, x='shipping_method', 
                                            title='Shipping Method Distribution',
                                            nbins=3)
                    st.plotly_chart(fig_method, use_container_width=True)
                
                # Store data in session state
                st.session_state.training_data = df
                
                # Model training section
                st.subheader("🤖 Train Model")
                
                model_type = st.selectbox("Select Model Type", 
                    ["Random Forest", "Linear Regression"])
                
                if st.button("Train Model", type="primary"):
                    with st.spinner("Training model..."):
                        try:
                            # Initialize predictor
                            predictor = DeliveryTimePredictor()
                            
                            # Prepare features and target
                            X = df[['distance', 'weight', 'shipping_method']]
                            y = df['delivery_days']
                            
                            # Train model
                            if model_type == "Random Forest":
                                model_metrics = predictor.train_random_forest(X, y)
                            else:
                                model_metrics = predictor.train_linear_regression(X, y)
                            
                            # Store model and metrics
                            st.session_state.model = predictor
                            st.session_state.model_metrics = model_metrics
                            
                            st.success("✅ Model trained successfully!")
                            st.json(model_metrics)
                            
                        except Exception as e:
                            st.error(f"❌ Error training model: {str(e)}")
                            
            else:
                st.error(f"❌ Data validation failed: {error_msg}")
                
        except Exception as e:
            st.error(f"❌ Error loading file: {str(e)}")

elif page == "Make Predictions":
    st.header("🔮 Make Predictions")
    
    if st.session_state.model is None:
        st.warning("⚠️ Please train a model first in the 'Data Upload & Training' page.")
    else:
        st.success("✅ Model is ready for predictions!")
        
        # Prediction form
        st.subheader("Enter Package Details")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            distance = st.number_input("Distance (km)", min_value=1, max_value=5000, value=300, step=1)
        
        with col2:
            weight = st.number_input("Weight (kg)", min_value=0.1, max_value=100.0, value=2.5, step=0.1)
        
        with col3:
            shipping_method = st.selectbox("Shipping Method", 
                                         options=[1, 2], 
                                         format_func=lambda x: "Standard" if x == 1 else "Priority",
                                         index=0)
        
        if st.button("Predict Delivery Time", type="primary"):
            try:
                # Make prediction
                prediction = st.session_state.model.predict_single(distance, weight, shipping_method)
                
                st.subheader("Prediction Results")
                
                # Display main prediction
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Predicted Delivery Time", f"{prediction:.1f} days")
                
                with col2:
                    method_name = "Standard" if shipping_method == 1 else "Priority"
                    st.metric("Shipping Method", method_name)
                
                # Compare shipping methods
                st.subheader("📊 Shipping Method Comparison")
                
                pred_standard = st.session_state.model.predict_single(distance, weight, 1)
                pred_priority = st.session_state.model.predict_single(distance, weight, 2)
                
                comparison_df = pd.DataFrame({
                    'Shipping Method': ['Standard', 'Priority'],
                    'Predicted Days': [pred_standard, pred_priority],
                    'Cost Efficiency': ['Lower Cost', 'Higher Cost']
                })
                
                st.dataframe(comparison_df, use_container_width=True)
                
                # Recommendation
                time_saved = pred_standard - pred_priority
                st.subheader("💡 Recommendation")
                
                if time_saved > 1:
                    st.success(f"💎 Consider Priority shipping - saves {time_saved:.1f} days!")
                elif time_saved > 0.5:
                    st.info(f"⚖️ Priority shipping saves {time_saved:.1f} days - consider if time is critical.")
                else:
                    st.info("📦 Standard shipping is recommended - minimal time difference.")
                
            except Exception as e:
                st.error(f"❌ Error making prediction: {str(e)}")

elif page == "Model Performance":
    st.header("📈 Model Performance")
    
    if st.session_state.model is None or st.session_state.model_metrics is None:
        st.warning("⚠️ Please train a model first in the 'Data Upload & Training' page.")
    else:
        metrics = st.session_state.model_metrics
        
        # Display metrics
        st.subheader("Performance Metrics")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Mean Absolute Error", f"{metrics['mae']:.2f} days")
        with col2:
            st.metric("Root Mean Squared Error", f"{metrics['rmse']:.2f} days")
        with col3:
            st.metric("R² Score", f"{metrics['r2_score']:.3f}")
        
        # Model predictions vs actual
        if hasattr(st.session_state.model, 'y_test') and hasattr(st.session_state.model, 'y_pred'):
            st.subheader("Predictions vs Actual Values")
            
            fig_scatter = go.Figure()
            fig_scatter.add_trace(go.Scatter(
                x=st.session_state.model.y_test,
                y=st.session_state.model.y_pred,
                mode='markers',
                name='Predictions',
                opacity=0.6
            ))
            
            # Add perfect prediction line
            min_val = min(st.session_state.model.y_test.min(), st.session_state.model.y_pred.min())
            max_val = max(st.session_state.model.y_test.max(), st.session_state.model.y_pred.max())
            fig_scatter.add_trace(go.Scatter(
                x=[min_val, max_val],
                y=[min_val, max_val],
                mode='lines',
                name='Perfect Prediction',
                line=dict(dash='dash', color='red')
            ))
            
            fig_scatter.update_layout(
                xaxis_title='Actual Delivery Days',
                yaxis_title='Predicted Delivery Days',
                title='Model Predictions vs Actual Values'
            )
            
            st.plotly_chart(fig_scatter, use_container_width=True)
        
        # Residuals plot
        if hasattr(st.session_state.model, 'y_test') and hasattr(st.session_state.model, 'y_pred'):
            st.subheader("Residuals Analysis")
            
            residuals = st.session_state.model.y_test - st.session_state.model.y_pred
            
            fig_residuals = px.scatter(x=st.session_state.model.y_pred, y=residuals,
                                     labels={'x': 'Predicted Values', 'y': 'Residuals'},
                                     title='Residuals vs Predicted Values')
            fig_residuals.add_hline(y=0, line_dash="dash", line_color="red")
            
            st.plotly_chart(fig_residuals, use_container_width=True)

elif page == "Feature Analysis":
    st.header("🔍 Feature Analysis")
    
    if st.session_state.model is None or st.session_state.training_data is None:
        st.warning("⚠️ Please train a model first in the 'Data Upload & Training' page.")
    else:
        df = st.session_state.training_data
        
        # Feature importance (for Random Forest)
        if hasattr(st.session_state.model, 'get_feature_importance'):
            st.subheader("Feature Importance")
            
            importance_data = st.session_state.model.get_feature_importance()
            if importance_data is not None:
                fig_importance = px.bar(
                    x=importance_data['importance'],
                    y=importance_data['feature'],
                    orientation='h',
                    title='Feature Importance in Delivery Time Prediction'
                )
                st.plotly_chart(fig_importance, use_container_width=True)
        
        # Correlation analysis
        st.subheader("Feature Correlations")
        
        corr_matrix = df[['distance', 'weight', 'shipping_method', 'delivery_days']].corr()
        fig_corr = px.imshow(corr_matrix, 
                           text_auto=True, 
                           aspect="auto",
                           title='Correlation Matrix of Features')
        st.plotly_chart(fig_corr, use_container_width=True)
        
        # Feature relationships
        st.subheader("Feature Relationships")
        
        col1, col2 = st.columns(2)
        
        with col1:
            fig_dist = px.scatter(df, x='distance', y='delivery_days', 
                                color='shipping_method',
                                title='Distance vs Delivery Days',
                                labels={'shipping_method': 'Shipping Method'})
            st.plotly_chart(fig_dist, use_container_width=True)
        
        with col2:
            fig_weight = px.scatter(df, x='weight', y='delivery_days',
                                  color='shipping_method',
                                  title='Weight vs Delivery Days',
                                  labels={'shipping_method': 'Shipping Method'})
            st.plotly_chart(fig_weight, use_container_width=True)
        
        # Summary statistics by shipping method
        st.subheader("Statistics by Shipping Method")
        
        stats_by_method = df.groupby('shipping_method').agg({
            'delivery_days': ['mean', 'std', 'min', 'max'],
            'distance': 'mean',
            'weight': 'mean'
        }).round(2)
        
        stats_by_method.columns = ['Avg Days', 'Std Days', 'Min Days', 'Max Days', 'Avg Distance', 'Avg Weight']
        stats_by_method.index = ['Standard', 'Priority']
        
        st.dataframe(stats_by_method, use_container_width=True)

# Footer
st.markdown("---")
st.markdown("📦 Package Delivery Time Predictor - Built with Streamlit")
