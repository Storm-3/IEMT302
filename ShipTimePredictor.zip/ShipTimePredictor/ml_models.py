import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
import pickle

class DeliveryTimePredictor:
    """
    Machine Learning model for predicting package delivery times
    """
    
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.model_type = None
        self.feature_names = ['distance', 'weight', 'shipping_method']
        self.X_test = None
        self.y_test = None
        self.y_pred = None
        
    def prepare_features(self, X, y=None, fit_scaler=False):
        """
        Prepare features for training or prediction
        
        Args:
            X: Input features
            y: Target variable (optional)
            fit_scaler: Whether to fit the scaler (True for training)
        
        Returns:
            Processed features and optionally target
        """
        # Ensure X is a DataFrame
        if not isinstance(X, pd.DataFrame):
            X = pd.DataFrame(X, columns=self.feature_names)
        
        # Validate required columns
        required_cols = ['distance', 'weight', 'shipping_method']
        for col in required_cols:
            if col not in X.columns:
                raise ValueError(f"Missing required column: {col}")
        
        # Select only required features
        X_processed = X[required_cols].copy()
        
        # Handle any missing values
        X_processed = X_processed.fillna(X_processed.median())
        
        # Scale features for linear regression
        if self.model_type == 'linear_regression':
            if fit_scaler:
                X_processed = pd.DataFrame(
                    self.scaler.fit_transform(X_processed),
                    columns=X_processed.columns,
                    index=X_processed.index
                )
            else:
                X_processed = pd.DataFrame(
                    self.scaler.transform(X_processed),
                    columns=X_processed.columns,
                    index=X_processed.index
                )
        
        if y is not None:
            return X_processed, y
        return X_processed
    
    def train_random_forest(self, X, y, test_size=0.2, random_state=42):
        """
        Train a Random Forest model for delivery time prediction
        
        Args:
            X: Feature matrix
            y: Target variable (delivery days)
            test_size: Proportion of data to use for testing
            random_state: Random seed for reproducibility
        
        Returns:
            Dictionary containing model performance metrics
        """
        self.model_type = 'random_forest'
        
        # Prepare features
        X_processed, y_processed = self.prepare_features(X, y, fit_scaler=False)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X_processed, y_processed, test_size=test_size, random_state=random_state
        )
        
        # Initialize and train model
        self.model = RandomForestRegressor(
            n_estimators=100,
            max_depth=10,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=random_state
        )
        
        self.model.fit(X_train, y_train)
        
        # Make predictions
        y_pred = self.model.predict(X_test)
        
        # Store test data for visualization
        self.X_test = X_test
        self.y_test = y_test
        self.y_pred = y_pred
        
        # Calculate metrics
        metrics = {
            'mae': mean_absolute_error(y_test, y_pred),
            'rmse': np.sqrt(mean_squared_error(y_test, y_pred)),
            'r2_score': r2_score(y_test, y_pred),
            'model_type': 'Random Forest'
        }
        
        return metrics
    
    def train_linear_regression(self, X, y, test_size=0.2, random_state=42):
        """
        Train a Linear Regression model for delivery time prediction
        
        Args:
            X: Feature matrix
            y: Target variable (delivery days)
            test_size: Proportion of data to use for testing
            random_state: Random seed for reproducibility
        
        Returns:
            Dictionary containing model performance metrics
        """
        self.model_type = 'linear_regression'
        
        # Prepare features (with scaling)
        X_processed, y_processed = self.prepare_features(X, y, fit_scaler=True)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X_processed, y_processed, test_size=test_size, random_state=random_state
        )
        
        # Initialize and train model
        self.model = LinearRegression()
        self.model.fit(X_train, y_train)
        
        # Make predictions
        y_pred = self.model.predict(X_test)
        
        # Store test data for visualization
        self.X_test = X_test
        self.y_test = y_test
        self.y_pred = y_pred
        
        # Calculate metrics
        metrics = {
            'mae': mean_absolute_error(y_test, y_pred),
            'rmse': np.sqrt(mean_squared_error(y_test, y_pred)),
            'r2_score': r2_score(y_test, y_pred),
            'model_type': 'Linear Regression'
        }
        
        return metrics
    
    def predict_single(self, distance, weight, shipping_method):
        """
        Make a prediction for a single package
        
        Args:
            distance: Distance in kilometers
            weight: Package weight in kilograms
            shipping_method: 1 for standard, 2 for priority
        
        Returns:
            Predicted delivery time in days
        """
        if self.model is None:
            raise ValueError("Model not trained yet. Please train a model first.")
        
        # Create feature array
        features = pd.DataFrame({
            'distance': [distance],
            'weight': [weight],
            'shipping_method': [shipping_method]
        })
        
        # Prepare features
        features_processed = self.prepare_features(features)
        
        # Make prediction
        prediction = self.model.predict(features_processed)
        
        return max(0, prediction[0])  # Ensure non-negative prediction
    
    def predict_batch(self, X):
        """
        Make predictions for multiple packages
        
        Args:
            X: Feature matrix with columns [distance, weight, shipping_method]
        
        Returns:
            Array of predicted delivery times
        """
        if self.model is None:
            raise ValueError("Model not trained yet. Please train a model first.")
        
        # Prepare features
        X_processed = self.prepare_features(X)
        
        # Make predictions
        predictions = self.model.predict(X_processed)
        
        return np.maximum(0, predictions)  # Ensure non-negative predictions
    
    def get_feature_importance(self):
        """
        Get feature importance for Random Forest model
        
        Returns:
            Dictionary with feature names and their importance scores
        """
        if self.model is None:
            raise ValueError("Model not trained yet. Please train a model first.")
        
        if self.model_type != 'random_forest':
            return None
        
        importance_scores = self.model.feature_importances_
        feature_importance = pd.DataFrame({
            'feature': self.feature_names,
            'importance': importance_scores
        }).sort_values('importance', ascending=True)
        
        return feature_importance
    
    def save_model(self, filepath):
        """
        Save the trained model to a file
        
        Args:
            filepath: Path to save the model
        """
        if self.model is None:
            raise ValueError("No model to save. Please train a model first.")
        
        model_data = {
            'model': self.model,
            'scaler': self.scaler,
            'model_type': self.model_type,
            'feature_names': self.feature_names
        }
        
        with open(filepath, 'wb') as f:
            pickle.dump(model_data, f)
    
    def load_model(self, filepath):
        """
        Load a trained model from a file
        
        Args:
            filepath: Path to the saved model
        """
        with open(filepath, 'rb') as f:
            model_data = pickle.load(f)
        
        self.model = model_data['model']
        self.scaler = model_data['scaler']
        self.model_type = model_data['model_type']
        self.feature_names = model_data['feature_names']
