# Package Delivery Time Predictor

## Overview

This is a machine learning-powered web application built with Streamlit that predicts package delivery times based on distance, package weight, and shipping method. The application provides an interactive interface for data upload, model training, prediction generation, and performance analysis. It supports multiple ML algorithms including Random Forest and Linear Regression, with built-in data validation and visualization capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Streamlit Web Framework**: Single-page application with multi-page navigation using sidebar selection
- **Interactive Components**: File upload widgets, form inputs, data visualization charts, and expandable sections
- **Session State Management**: Persistent storage of trained models, training data, and metrics across page interactions
- **Responsive Layout**: Wide layout configuration optimized for data visualization and model interaction

### Machine Learning Architecture
- **Model Classes**: Object-oriented design with `DeliveryTimePredictor` class encapsulating ML functionality
- **Algorithm Support**: Multiple regression algorithms (Random Forest, Linear Regression) with unified interface
- **Feature Engineering**: Standardized preprocessing pipeline with sklearn StandardScaler
- **Model Persistence**: Pickle-based serialization for model saving and loading
- **Validation Framework**: Built-in train/test splitting with comprehensive performance metrics

### Data Processing Pipeline
- **Input Validation**: Strict schema validation for required columns (distance, weight, shipping_method, delivery_days)
- **Data Type Checking**: Numeric validation with range constraints and business logic validation
- **Error Handling**: Comprehensive error messages and graceful degradation for invalid inputs
- **Sample Data Generation**: Built-in functionality to create example datasets for testing

### Application Structure
- **Modular Design**: Separation of concerns with dedicated modules for ML models (`ml_models.py`), data utilities (`data_utils.py`), and main application (`app.py`)
- **Page-based Navigation**: Multi-page interface with distinct sections for training, prediction, performance analysis, and feature exploration
- **State Management**: Session-based persistence ensuring model and data availability across navigation

## External Dependencies

### Core ML and Data Science Libraries
- **scikit-learn**: Machine learning algorithms, preprocessing, and evaluation metrics
- **pandas**: Data manipulation and CSV file processing
- **numpy**: Numerical computing and array operations

### Visualization and UI Framework
- **Streamlit**: Web application framework and UI components
- **Plotly Express & Graph Objects**: Interactive data visualization and charting

### Model Persistence
- **pickle**: Python object serialization for model saving/loading
- **io**: File handling and in-memory data processing

### Data Format Requirements
- **CSV Input**: Structured data with specific column requirements (distance, weight, shipping_method, delivery_days)
- **Numeric Constraints**: Distance and weight must be positive, shipping method must be 1 (standard) or 2 (priority)
- **Business Logic Validation**: Reasonable ranges for distance (<10000km) and delivery times